"""UI audit probes: real Chromium (Playwright) + emulated Telegram WebApp launch params. NOT real Telegram."""
import hashlib
import hmac
import json
import tempfile
import time
import unittest
import urllib.parse

from playwright.sync_api import sync_playwright

from tests import test_app as T

OUT = {}
SHOTS = "/tmp/claude-0/-home-claude/613aa0e9-22f4-572d-aa67-22d168d823e9/scratchpad/shots"


def setUpModule():
    T.setUpModule()


def init_data(user):
    f = {"user": json.dumps(user, separators=(",", ":")), "auth_date": str(int(time.time())), "query_id": "AAH"}
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(f.items()))
    secret = hmac.new(b"WebAppData", b"1:TESTTOKEN", hashlib.sha256).digest()
    f["hash"] = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode(f)


def rec(k, v):
    OUT[k] = v
    print("UI", k, "=>", json.dumps(v, ensure_ascii=False, default=str)[:600], flush=True)


LUM = """(el)=>{const c=getComputedStyle(el).backgroundColor;const m=c.match(/[\\d.]+/g)||[];
 const [r,g,b,a]=[+m[0],+m[1],+m[2],m[3]===undefined?1:+m[3]];return {c, lum:(0.2126*r+0.7152*g+0.0722*b)/255, a}}"""


class UI(unittest.TestCase):
    def test_miniapp(self):
        import os
        os.makedirs(SHOTS, exist_ok=True)
        c, u, chat, res = T.make_user_with_channel("UI probe chan")
        T.db.run("UPDATE users SET plan='free' WHERE telegram_id=?", u["id"])
        png = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        png.write(T.tiny_png()); png.close()
        hashparam = "tgWebAppData=" + urllib.parse.quote(init_data(u), safe="") + "&tgWebAppVersion=7.0"
        with sync_playwright() as pw:
            br = pw.chromium.launch()
            ctx = br.new_context(viewport={"width": 390, "height": 844}, color_scheme="dark", device_scale_factor=1)
            page = ctx.new_page()
            console = []
            page.on("console", lambda m: console.append(f"{m.type}: {m.text}"[:300]))
            page.route("https://telegram.org/**", lambda r: r.abort())
            page.goto(T.BASE + "/app/#" + hashparam)
            page.wait_for_selector("nav#nav .nav-label", timeout=15000)
            page.wait_for_timeout(800)
            page.screenshot(path=f"{SHOTS}/home_dark.png")
            labels = page.eval_on_selector_all(".nav-label", "els=>els.map(e=>({t:e.textContent,sw:e.scrollWidth,cw:e.clientWidth}))")
            rec("nav_labels", labels)
            rec("page_horizontal_overflow", page.evaluate("document.documentElement.scrollWidth>document.documentElement.clientWidth"))
            # profile
            page.click("nav#nav button:has-text('Профиль')")
            page.wait_for_timeout(600)
            prof = page.inner_text("#view")
            rec("profile_text_plan_lines", [l for l in prof.splitlines() if "ариф" in l or "PRO" in l or "BUSINESS" in l or "Бесплат" in l or "none" in l.lower()])
            page.screenshot(path=f"{SHOTS}/profile_dark.png")
            page.click("button:has-text('Тарифы и оплата')")
            page.wait_for_selector(".sheet .card", timeout=8000)
            page.wait_for_timeout(500)
            rec("tariff_sheet_text", page.inner_text(".sheet")[:900])
            rec("tariff_pay_buttons", page.locator(".sheet button:has-text('Оплатить')").count())
            page.screenshot(path=f"{SHOTS}/tariffs_dark.png")
            page.click(".sheet-head button")
            page.wait_for_timeout(300)
            # tools
            page.click("nav#nav button:has-text('Инструменты')")
            page.wait_for_timeout(600)
            tools = page.inner_text("#view")
            rec("tools_text", tools[:700])
            page.screenshot(path=f"{SHOTS}/tools_dark.png")
            # posts + calendar
            page.click("nav#nav button:has-text('Публикации')")
            page.wait_for_timeout(600)
            has_cal_btn = page.locator("#view button:has-text('Календарь')").count()
            rec("calendar_toggle_present", has_cal_btn)
            if has_cal_btn:
                page.click("#view button:has-text('Календарь')")
                page.wait_for_timeout(700)
                rec("calendar_title", page.inner_text(".cal-title") if page.locator(".cal-title").count() else None)
                rec("calendar_modes", page.locator("#view button:has-text('Неделя')").count() + page.locator("#view button:has-text('Месяц')").count())
                page.screenshot(path=f"{SHOTS}/calendar_dark.png")
                page.click("#view button:has-text('Список')")
                page.wait_for_timeout(300)
            # composer + photo preview
            fab = page.locator(".fab")
            rec("fab_visible", fab.is_visible() if fab.count() else None)
            fab.click()
            page.wait_for_selector("input[type=file]", state="attached", timeout=8000)
            before = len(console)
            page.set_input_files("input[type=file]", png.name)
            page.wait_for_timeout(1500)
            info = page.evaluate("""()=>[...document.querySelectorAll('img')].map(i=>({src:i.src.slice(0,40),nw:i.naturalWidth,complete:i.complete}))""")
            rec("composer_images_after_upload", info)
            rec("console_after_upload", console[before:])
            page.screenshot(path=f"{SHOTS}/composer_dark.png")
            # dark theme native fields
            fields = page.evaluate("""()=>[...document.querySelectorAll('input,select,textarea')].filter(e=>e.type!=='file'&&e.type!=='checkbox'&&e.type!=='hidden').map(e=>({tag:e.tagName,type:e.type,bg:getComputedStyle(e).backgroundColor,color:getComputedStyle(e).color}))""")
            rec("composer_fields_dark", fields[:8])
            rec("all_console_errors", [x for x in console if x.startswith(("error", "warning"))][:10])
            br.close()


def tearDownModule():
    T.tearDownModule()
    with open("/tmp/claude-0/-home-claude/613aa0e9-22f4-572d-aa67-22d168d823e9/scratchpad/ui.json", "w") as f:
        json.dump(OUT, f, ensure_ascii=False, indent=1, default=str)


if __name__ == "__main__":
    unittest.main()
