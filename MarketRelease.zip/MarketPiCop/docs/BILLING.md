# Community billing and manual payouts

## Scope

Community plans are sold in RUB. A buyer makes one YooKassa payment to the platform shop. MarketPilot records the 1.5% platform commission and the remaining amount due to the community owner; the platform administrator transfers that amount manually using the owner's saved phone number and bank. This is not a split payment or an automatic SBP payout. YooKassa controls which payment methods (including SBP, if enabled for the shop) appear at checkout. Telegram Stars are not supported. Both public and private groups/supergroups are supported. Group membership is not paywalled: in public groups anyone can join, and payment grants only the plan's configured member privileges. The bot must be an administrator with member-restriction rights; invite rights are needed only to send an invite for private groups.

A buyer explicitly opts in to auto-renewal at checkout. It is off by default. The scheduler charges the saved YooKassa payment method at the subscription end date, sends a notice up to three days before renewal, and disables renewal after a provider-declined charge. A full refund is requested by the buyer, approved or rejected by the community owner, and tariff privileges are revoked only after YooKassa confirms the refund. Members of public groups stay in the group and return to its default permissions after expiry/refund; members of private groups are removed.

Community purchases and recurring charges are disabled by default. Keep `COMMUNITY_PAYMENTS_ENABLED=0` while testing; the API rejects checkout and the scheduler does not issue renewals. Enable it only after confirming the platform shop, public HTTPS address, webhook, and manual payout process. Auto-renewal is opt-in; recurring YooKassa charges still go to the platform shop, with the owner's share added to the manual payout queue.

## Payment and payout setup

### Platform administrator

1. Confirm with YooKassa and your legal/accounting advisers that your shop and agreement allow you to collect these community payments and manually pay community owners. The software does not determine your legal, tax, or receipt obligations.
2. Set the platform shop ID and API key in the server's local `.env`. Never put the secret in the Mini App, source control, screenshots, or chat:

```dotenv
YOOKASSA_SHOP_ID=
YOOKASSA_SECRET_KEY=
COMMUNITY_PAYMENTS_ENABLED=0
YOOKASSA_API_URL=https://api.yookassa.ru/v3
PLATFORM_COMMISSION_BPS=150
PLATFORM_ADMIN_TELEGRAM_IDS=123456789
PUBLIC_URL=https://your-domain.example
COOKIE_SECURE=1
```

Keep `.env` local and make sure it is ignored by Git. `PLATFORM_ADMIN_TELEGRAM_IDS` is a comma-separated allowlist of trusted numeric Telegram user IDs; only these accounts can see payout details for all owners and mark manual transfers as paid. Owners and workspace owners can see their own payout details; other workspace members cannot. Phone and bank details are stored in the application's SQLite database, so restrict server and backup access. Use test credentials for test purchases; live credentials can cause real charges. `COMMUNITY_PAYMENTS_ENABLED=0` blocks checkout and auto-renewal even when YooKassa credentials are present. Set it to `1` only after approval and testing. `BILLING_MODE` does not put YooKassa into test mode.
3. Use a publicly reachable HTTPS `PUBLIC_URL` and configure the YooKassa notification URL as `https://your-domain.example/api/v1/webhooks/yookassa` for successful and canceled payments and successful refunds. The handler retrieves each payment/refund from YooKassa using server credentials before changing local state; webhook bodies alone never activate access. A preview URL that redirects to a sign-in page is not suitable for notifications.
4. Restart MarketPilot after changing `.env`, then verify the app status and run the integration tests. Integration tests use a local fake provider and do not verify real-money transactions.
5. In **Инструменты → Подписки**, the allowlisted administrator sees the manual payout queue. After making the transfer in the bank app, mark it as paid and optionally save a transfer reference. Verify every transfer in the bank app first; this action only updates MarketPilot's record and does not initiate a bank transfer.

### Community owner

1. Ask the platform administrator to confirm that payments are enabled and the site is available at a public HTTPS address. Community owners must not enter the platform secret key.
2. In **Инструменты → Подписки**, choose an active group/supergroup, enter the phone number registered for SBP and the bank, then save the details. These details are stored by the application and visible to the owner and allowlisted platform administrators; do not enter a card number, CVV, or online-banking credentials.
3. Create a tariff with a name, description, price in RUB, privilege duration, optional maximum number of subscribers, a daily per-member message quota, and (for supergroups) individual Telegram permissions. Buyers pay the platform; the owner is due the tariff amount less the 1.5% platform commission and receives it through a manual transfer. Public groups remain freely accessible.
4. Configure standard group permissions in the same section. This changes Telegram's default permissions for all group members, and is available for basic groups and supergroups. Messages above the tariff quota are deleted; group admins are exempt.
5. Before offering a tariff, verify that the bot is an administrator with member-restriction rights. Invite rights are required only for private groups. Make a small test purchase and refund using provider test credentials before switching to live payments.

If the community is still a basic group, convert it to a supergroup in Telegram first. The bot cannot perform this conversion. MarketPilot updates the connected resource when Telegram sends the group migration service message; after that, refresh the app to configure per-member permissions.

For each supergroup tariff, the owner can allow or deny text, audio, documents, photos, videos, video/voice notes, polls, stickers/GIFs/inline apps, link previews, inviting members, pinning messages, managing topics, and changing group information. Telegram applies these restrictions to a paid member after they join. The selected permissions must also be allowed by the group's default permissions; a tariff cannot grant rights that the group itself disables. Per-member permission controls are only available for supergroups. When a tariff expires or a refund is confirmed, a public-group member stays in the group with the group's default permissions; a private-group member is removed.

## API and accounting

- `GET /api/v1/marketplace/plans` lists purchasable tariffs.
- `PUT /api/v1/communities/{id}/merchant` saves the community owner's payout phone and bank; `POST /api/v1/communities/{id}/plans` creates a tariff.
- `POST /api/v1/community-plans/{id}/checkout` creates a payment only when `COMMUNITY_PAYMENTS_ENABLED=1`; `auto_renew` is opt-in.
- `GET /api/v1/community-subscriptions` and `/api/v1/owner/community-billing` serve buyer and owner dashboards.
- `GET /api/v1/platform/payouts` and `POST /api/v1/platform/payouts/{id}/paid` are restricted to `PLATFORM_ADMIN_TELEGRAM_IDS`; the latter records a manual transfer but does not execute one.
- Refunds are requested at `/api/v1/community-subscriptions/{id}/refunds`; the owner approves or rejects them at `/api/v1/community-refunds/{id}/approve` or `/reject`.
- Payment, subscription, refund, ledger, and access-job records are scoped to the owner's workspace. Provider event IDs and YooKassa idempotency keys protect against repeated requests and notifications.

The owner ledger records RUB sales, platform commission, and the amount due to the owner. Successful payments create a pending manual payout; a confirmed refund cancels a pending payout or flags a previously paid one for recovery. No automatic seller transfer, Stars wallet, or Stars-to-RUB conversion is implemented.
