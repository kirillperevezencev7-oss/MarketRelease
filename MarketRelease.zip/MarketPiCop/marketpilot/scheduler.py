"""Publishing executor and periodic jobs.

Guarantees (see docs/product/01-spec-review.md):
- A due target is claimed with an atomic UPDATE ... WHERE status='scheduled' -> 'publishing'
  before any network call, so it can never be sent twice by this process.
- 400/403 -> failed (no retry). 429 -> rescheduled after retry_after (attempt not counted).
- A network failure AFTER the request was sent is ambiguous -> status `unknown`, never auto-retried.
- A target stuck in `publishing` (process killed mid-send) becomes `unknown` after STUCK_AFTER.
- Demo resources: publication is simulated (message id is fake), nothing reaches Telegram.
"""
import json
import logging
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta

from . import bot, db, marketplace, telegram
from .config import cfg
from .telegram import TelegramError, TelegramNetworkError

log = logging.getLogger("marketpilot.scheduler")

MAX_ATTEMPTS = 3
STUCK_AFTER = timedelta(minutes=5)
BATCH = 20


def recover_stuck() -> int:
    cur = db.run(
        "UPDATE post_targets SET status='unknown', error=? WHERE status='publishing' AND started_at<?",
        "Процесс остановился во время отправки; проверьте канал перед повторной отправкой",
        db.iso(db.now() - STUCK_AFTER),
    )
    return cur.rowcount


def claim_due() -> list[int]:
    now = db.now_iso()
    rows = db.q(
        "SELECT id FROM post_targets WHERE status='scheduled' AND scheduled_at<=? "
        "AND (next_attempt_at IS NULL OR next_attempt_at<=?) ORDER BY scheduled_at LIMIT ?",
        now, now, BATCH,
    )
    claimed = []
    for r in rows:
        cur = db.run(
            "UPDATE post_targets SET status='publishing', started_at=?, attempts=attempts+1 "
            "WHERE id=? AND status='scheduled'", now, r["id"])
        if cur.rowcount == 1:
            claimed.append(r["id"])
    return claimed


def _finish(target, status, **fields) -> None:
    sets = ", ".join(f"{k}=?" for k in fields)
    db.run(f"UPDATE post_targets SET status=?, {sets} WHERE id=?" if sets else "UPDATE post_targets SET status=? WHERE id=?",
           status, *fields.values(), target["id"])


def deliver(target_id: int) -> None:
    t = db.one("SELECT * FROM post_targets WHERE id=?", target_id)
    if t is None or t["status"] != "publishing":
        return
    from .api import cancel_scheduled_posts, feature_enabled
    if not feature_enabled({"id": t["user_id"]}, "scheduler"):
        cancel_scheduled_posts(t["user_id"], "Тарифный доступ к отложенным публикациям завершён")
        return _finish(t, "cancelled", error="Тарифный доступ к отложенным публикациям завершён")
    post = db.one("SELECT * FROM posts WHERE id=?", t["post_id"])
    res = db.one("SELECT * FROM resources WHERE id=?", t["resource_id"])
    if post is None or res is None:
        return _finish(t, "failed", error="post or resource no longer exists")

    if res["status"] == "disconnected":
        return _finish(t, "cancelled", error="resource disconnected")
    if res["status"] != "active" or "publish" not in db.jl(res["capabilities"]):
        err = "У бота нет прав на публикацию в этом ресурсе: " + ", ".join(db.jl(res["missing_rights"]) or ["publish"])
        _finish(t, "failed", error=err)
        db.event(t["user_id"], "publish_failed", f"Ошибка публикации в «{res['title']}»: нет прав", res["id"])
        bot.notify_owner(t["user_id"], f"❌ Не удалось опубликовать в «{res['title']}»: у бота нет прав.")
        return

    if res["is_demo"]:  # simulated send
        time.sleep(0.2)
        _finish(t, "published", message_id=random.randint(10_000, 99_999), published_at=db.now_iso(), error=None)
        db.event(t["user_id"], "published", f"Опубликовано в «{res['title']}» (демо: в Telegram не отправлялось)", res["id"])
        return

    c = telegram.client()
    if c is None or not telegram.is_live():
        # no connection: not sent, safe to retry later
        return _retry_later(t, res, "Нет связи с Telegram", attempt_counts=False, delay=30)

    uploaded_media = None
    if post["image_url"] and post["image_url"].startswith("upload:"):
        try:
            media_id = int(post["image_url"].partition(":")[2])
        except ValueError:
            media_id = 0
        uploaded_media = db.one("SELECT * FROM media_uploads WHERE id=? AND user_id=?", media_id, t["user_id"])
        if uploaded_media is None:
            _finish(t, "failed", error="Загруженное изображение не найдено")
            db.event(t["user_id"], "publish_failed", f"Не найдено изображение для «{res['title']}»", res["id"])
            bot.notify_owner(t["user_id"], f"❌ Не найдено загруженное изображение для публикации в «{res['title']}».")
            return

    try:
        if post["image_url"]:
            if uploaded_media:
                result = c.send_photo_file(res["chat_id"], uploaded_media["data"], uploaded_media["filename"],
                                           uploaded_media["mime"], post["text"])
            else:
                result = c.send_photo(res["chat_id"], post["image_url"], post["text"])
        else:
            result = c.send_message(res["chat_id"], post["text"])
        _finish(t, "published", message_id=result["message_id"], published_at=db.now_iso(), error=None)
        db.event(t["user_id"], "published", f"Опубликовано в «{res['title']}»", res["id"])
    except TelegramError as e:
        if e.code == 429:
            _retry_later(t, res, str(e), attempt_counts=False, delay=(e.retry_after or 5) + 1)
        elif e.permanent or t["attempts"] >= MAX_ATTEMPTS:
            _finish(t, "failed", error=str(e))
            if e.code == 403:
                db.run("UPDATE resources SET status='missing_rights' WHERE id=?", res["id"])
            db.event(t["user_id"], "publish_failed", f"Ошибка публикации в «{res['title']}»: {e.description}", res["id"])
            bot.notify_owner(t["user_id"], f"❌ Ошибка публикации в «{res['title']}»: {e.description}")
        else:
            _retry_later(t, res, str(e), attempt_counts=True, delay=30 * t["attempts"])
    except TelegramNetworkError as e:
        if e.ambiguous:
            _finish(t, "unknown", error=f"Нет ответа от Telegram ({e}); сообщение могло быть отправлено — проверьте канал")
            db.event(t["user_id"], "publish_unknown", f"Нет ответа от Telegram при отправке в «{res['title']}»", res["id"])
            bot.notify_owner(t["user_id"], f"⚠️ Не удалось подтвердить публикацию в «{res['title']}». Проверьте канал и при необходимости повторите.")
        else:
            _retry_later(t, res, str(e), attempt_counts=False, delay=30)


def _retry_later(t, res, error, attempt_counts: bool, delay: float) -> None:
    attempts = t["attempts"] if attempt_counts else max(0, t["attempts"] - 1)
    db.run("UPDATE post_targets SET status='scheduled', next_attempt_at=?, attempts=?, error=? WHERE id=?",
           db.iso(db.now() + timedelta(seconds=delay)), attempts, error, t["id"])


# ---------- periodic jobs ----------
def refresh_resource(res) -> None:
    """Re-check bot rights and take a member-count snapshot for one live resource."""
    c = telegram.client()
    try:
        chat = c.get_chat(res["chat_id"])
        chat_type = chat.get("type")
        chat_title = chat.get("title") or res["title"]
        chat_username = chat.get("username")
        if (chat_type in ("channel", "group", "supergroup") and
                (chat_type != res["type"] or chat_title != res["title"] or chat_username != res["username"])):
            db.run("UPDATE resources SET type=?,title=?,username=?,last_checked_at=? WHERE id=?",
                   chat_type, chat_title, chat_username, db.now_iso(), res["id"])
            if chat_type != res["type"]:
                db.event(res["user_id"], "resource_type_updated",
                         f"Тип ресурса «{chat_title}» синхронизирован с Telegram: {chat_type}", res["id"])
            res = dict(res)
            res["type"] = chat_type
            res["title"] = chat_title
            res["username"] = chat_username
        member = c.chat_member(res["chat_id"], telegram.state["bot_id"])
        count = c.member_count(res["chat_id"])
    except TelegramError as e:
        if e.code in (400, 403):
            if res["status"] != "disconnected":
                db.run("UPDATE resources SET status='disconnected', last_checked_at=? WHERE id=?", db.now_iso(), res["id"])
                db.event(res["user_id"], "rights_changed", f"Нет доступа к «{res['title']}», ресурс отключён", res["id"])
                bot.notify_owner(res["user_id"], f"⚠️ Нет доступа к «{res['title']}». Ресурс отключён.")
        return
    except TelegramNetworkError:
        return
    caps, missing = telegram.evaluate_rights(res["type"], member)
    status = "active" if "publish" in caps else "missing_rights"
    db.run("UPDATE resources SET status=?, capabilities=?, missing_rights=?, members=?, last_checked_at=? WHERE id=?",
           status, json.dumps(caps), json.dumps(missing), count, db.now_iso(), res["id"])
    db.insert("snapshots", resource_id=res["id"], members=count, taken_at=db.now_iso())
    if status != res["status"]:
        msg = f"Права бота в «{res['title']}» изменены" + (f": не хватает {', '.join(missing)}" if missing else "")
        db.event(res["user_id"], "rights_changed", msg, res["id"])
        if status != "active":
            bot.notify_owner(res["user_id"], "⚠️ " + msg)


def snapshot_all_live() -> None:
    for res in db.q("SELECT * FROM resources WHERE is_demo=0 AND status!='disconnected'"):
        refresh_resource(res)


def reconcile_account_billing() -> int:
    """Ensure paid account subscriptions revert to FREE once their period has ended."""
    now = db.now_iso()
    users = db.q(
        "SELECT DISTINCT user_id FROM subscriptions WHERE status IN ('active', 'cancelled') AND ends_at IS NOT NULL AND ends_at<=?",
        now,
    )
    processed = 0
    for row in users:
        user_id = row["user_id"]
        future = db.one(
            "SELECT * FROM subscriptions WHERE user_id=? AND status IN ('active', 'cancelled') AND ends_at IS NOT NULL AND ends_at>? ORDER BY id DESC LIMIT 1",
            user_id,
            now,
        )
        if future is not None:
            continue
        expired_rows = db.q(
            "SELECT * FROM subscriptions WHERE user_id=? AND status IN ('active', 'cancelled') AND ends_at IS NOT NULL AND ends_at<=? ORDER BY id DESC",
            user_id,
            now,
        )
        if not expired_rows:
            continue
        db.run("UPDATE subscriptions SET status='expired', auto_renew=0 WHERE user_id=? AND status IN ('active', 'cancelled') AND ends_at IS NOT NULL AND ends_at<=?",
               user_id, now)
        cur_plan = db.one("SELECT plan FROM users WHERE id=?", user_id)["plan"]
        if cur_plan not in ("free", "beta"):
            db.run("UPDATE users SET plan='free' WHERE id=?", user_id)
            from .api import cancel_scheduled_posts
            cancel_scheduled_posts(user_id, "Тарифный доступ к отложенным публикациям завершён")
        db.event(user_id, "subscription_expired",
                 f"Подписка {expired_rows[0]['plan']} истекла; тариф вернулся в FREE", None)
        processed += len(expired_rows)
    return processed


def run_forever(stop: threading.Event) -> None:
    pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="deliver")
    tick = 0
    last_snapshot = 0.0
    while not stop.is_set():
        try:
            if tick % 60 == 0:
                n = recover_stuck()
                if n:
                    log.warning("moved %s stuck targets to unknown", n)
                expired = reconcile_account_billing()
                if expired:
                    log.info("expired %s account subscription rows", expired)
            if tick % 3600 == 0:
                purged = db.purge_audit(cfg.AUDIT_RETENTION_DAYS)
                if purged:
                    log.info("purged %s old audit rows", purged)
            if tick % 60 == 0:
                pool.submit(_safe_marketplace_maintenance)
            for tid in claim_due():
                pool.submit(_safe_deliver, tid)
            if telegram.is_live() and time.monotonic() - last_snapshot > cfg.SNAPSHOT_INTERVAL_MIN * 60:
                last_snapshot = time.monotonic()
                pool.submit(snapshot_all_live)
        except Exception:
            log.exception("scheduler iteration failed")
        tick += 1
        stop.wait(1)
    pool.shutdown(wait=False)


def _safe_deliver(tid: int) -> None:
    try:
        deliver(tid)
    except Exception:
        log.exception("deliver %s crashed", tid)
        db.run("UPDATE post_targets SET status='unknown', error='internal error during sending' "
               "WHERE id=? AND status='publishing'", tid)


def _safe_marketplace_maintenance() -> None:
    try:
        marketplace.maintenance_tick()
    except Exception:
        log.exception("community billing maintenance failed")
