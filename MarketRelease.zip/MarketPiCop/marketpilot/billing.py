"""Payments for the platform's own tariffs (FREE / PRO / BUSINESS).

A tariff changes ONLY here, after the payment provider confirms the payment (re-read from the provider's API, amount
and currency checked), or through a platform administrator. Settling is idempotent: the pending -> succeeded switch is
a single conditional UPDATE, so a repeated webhook or a manual sync never extends the subscription twice."""
import re
from datetime import timedelta

from . import db, payments
from .config import PLANS, PUBLIC_PLANS, cfg
from .server import ApiError, route

NOT_FOUND = ApiError(404, "not_found", "Не найдено")


def _payment_dict(row) -> dict:
    return {"id": row["id"], "plan": row["plan"], "months": row["months"], "amount_minor": row["amount_minor"],
            "currency": row["currency"], "status": row["status"], "confirmation_url": row["confirmation_url"]
            if row["status"] == "pending" else None, "subscription_id": row["subscription_id"],
            "created_at": row["created_at"], "paid_at": row["paid_at"]}


@route("POST", "/api/v1/billing/checkout")
def checkout(req):
    plan = str(req.body.get("plan") or "").lower()
    if plan not in PUBLIC_PLANS or PLANS[plan]["price"] <= 0:
        raise ApiError(422, "validation", "Выберите тариф PRO или BUSINESS")
    try:
        months = int(req.body.get("months", 1) or 1)
    except (TypeError, ValueError):
        raise ApiError(422, "validation", "Срок должен быть числом месяцев")
    if not 1 <= months <= cfg.MAX_RENEW_MONTHS:
        raise ApiError(422, "validation", f"Срок — от 1 до {cfg.MAX_RENEW_MONTHS} месяцев")
    key = str(req.body.get("idempotency_key") or "")
    if not re.fullmatch(r"[A-Za-z0-9_-]{16,80}", key):
        raise ApiError(422, "validation", "Неверный ключ платежа")
    uid = req.user["id"]
    existing = db.one("SELECT * FROM platform_payments WHERE user_id=? AND idempotency_key=?", uid, key)
    if existing is not None:
        return _payment_dict(existing)
    if not cfg.PLATFORM_PAYMENTS_ENABLED or not payments.configured():
        raise ApiError(503, "payments_disabled", "Оплата тарифов пока не подключена")
    amount = PLANS[plan]["price"] * 100 * months
    pid = db.insert("platform_payments", user_id=uid, plan=plan, months=months, amount_minor=amount,
                    idempotency_key=key, created_at=db.now_iso())
    return_url = (cfg.PUBLIC_URL + "/app/") if cfg.PUBLIC_URL else "https://t.me"
    try:
        provider = payments.create_platform_payment(amount_minor=amount, payment_id=pid, plan=plan, months=months,
                                                    return_url=return_url, idempotency_key=f"platform-{pid}-{key}")
    except payments.PaymentProviderError as exc:
        if not exc.ambiguous:
            db.run("UPDATE platform_payments SET status='canceled' WHERE id=? AND status='pending'", pid)
        raise ApiError(503, "provider_unavailable", str(exc))
    confirmation = (provider.get("confirmation") or {}).get("confirmation_url")
    db.run("UPDATE platform_payments SET provider_payment_id=?, confirmation_url=? WHERE id=?",
           provider.get("id"), confirmation, pid)
    db.audit(uid, "platform_payment_created", method="POST", status=201, entity_id=pid, request_id=req.request_id)
    return 201, _payment_dict(db.one("SELECT * FROM platform_payments WHERE id=?", pid))


@route("GET", "/api/v1/billing/transactions")
def transactions(req):
    rows = db.q("SELECT * FROM platform_payments WHERE user_id=? ORDER BY id DESC LIMIT 100", req.user["id"])
    return {"items": [_payment_dict(row) for row in rows], "payments_enabled": bool(
        cfg.PLATFORM_PAYMENTS_ENABLED and payments.configured())}


@route("POST", "/api/v1/billing/payments/<int:id>/sync")
def sync_payment(req):
    """Re-read the payment from the provider (for a missed webhook). Never trusts the client."""
    row = db.one("SELECT * FROM platform_payments WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None or not row["provider_payment_id"]:
        raise NOT_FOUND
    try:
        provider = payments.get_payment(row["provider_payment_id"])
    except payments.PaymentProviderError as exc:
        raise ApiError(503, "provider_unavailable", str(exc))
    settle_platform_payment(provider)
    return _payment_dict(db.one("SELECT * FROM platform_payments WHERE id=?", row["id"]))


def settle_platform_payment(provider_payment: dict) -> bool:
    """Apply a provider payment to the account. Returns True only when this call activated the tariff."""
    metadata = provider_payment.get("metadata") or {}
    local_id = metadata.get("payment_id")
    if not local_id or not str(local_id).isdigit():
        raise ApiError(400, "payment_metadata_invalid", "Платёж не связан с заказом MarketPilot")
    local = db.one("SELECT * FROM platform_payments WHERE id=?", int(local_id))
    if local is None or local["provider_payment_id"] != provider_payment.get("id"):
        raise ApiError(404, "payment_not_found", "Заказ не найден")
    amount = provider_payment.get("amount") or {}
    if amount.get("currency") != "RUB" or amount.get("value") != payments.money(local["amount_minor"]):
        raise ApiError(400, "payment_amount_mismatch", "Сумма или валюта платежа не совпадает с заказом")
    status = provider_payment.get("status")
    if status == "canceled":
        db.run("UPDATE platform_payments SET status='canceled' WHERE id=? AND status='pending'", local["id"])
        return False
    if status != "succeeded":
        return False
    with db.tx():
        claimed = db.run("UPDATE platform_payments SET status='succeeded', paid_at=? WHERE id=? AND status='pending'",
                         db.now_iso(), local["id"])
        if claimed.rowcount != 1:
            return False  # already settled: a repeated webhook must not extend the period again
        latest = db.one("SELECT * FROM subscriptions WHERE user_id=? AND plan=? AND status IN ('active','cancelled') "
                        "AND ends_at>? ORDER BY id DESC LIMIT 1", local["user_id"], local["plan"], db.now_iso())
        base = db.parse_iso(latest["ends_at"]) if latest else db.now()
        end = db.iso(base + timedelta(days=30 * local["months"]))
        db.run("UPDATE subscriptions SET status='expired', auto_renew=0 WHERE user_id=? AND status IN ('active','cancelled')",
               local["user_id"])
        sub_id = db.insert("subscriptions", user_id=local["user_id"], plan=local["plan"], status="active",
                           started_at=db.now_iso(), ends_at=end, created_at=db.now_iso())
        db.run("UPDATE platform_payments SET subscription_id=? WHERE id=?", sub_id, local["id"])
        db.run("UPDATE users SET plan=? WHERE id=?", local["plan"], local["user_id"])
        db.event(local["user_id"], "subscription_paid",
                 f"Оплата подтверждена: тариф {local['plan'].upper()} активен до {end}", None)
    return True
